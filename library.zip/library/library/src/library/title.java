package library;

public class title extends String {

}
