package library;

public class book_name extends String {

}
