package library;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

class MyException extends Exception  
{  
     MyException(String message)  
     {  
          super(message);  
     }  
}  
interface New 
{  
     void Createbook();  
     void Searchbook();  
     void price();  
}  

class bookdet
{
	int b1;
	int id=0;
	String title=new String();
	String auhtor=new String();
	double price;
	int n;
	}
	


 class book extends bookdet implements New
 {
	 Scanner n=new Scanner(System.in);
	 void getinfo()
	 {
		 try {
		  System.out.print("Enter BookName: "); 
		  title=n.next();
          System.out.print("Enter author name: ");
          auhtor=n.next();
          System.out.print("Enter price: "); 
          price=n.nextDouble();
   
		 }
		 catch(Exception e) {
			 System.out.println("");
		 }}
		 public void Createbook() {
				// TODO Auto-generated method stub 
					try {
						getinfo();
						 System.out.println("NEW BOOK CREATED");
					}
					 catch(Exception e)  
			           {  
			                System.out.println("NO BOOK CREATED");  
			           }  				
					
				}
		 public void Searchbook() 
		 
		 {
				
				try
				{
					getinfo();
					  if(title.equals(title)&&auhtor.equals(auhtor))  
		                { 
		                     System.out.println("BOOK FOUND");  
		                }  
				}
				catch(Exception e)
				{
					System.out.println("INVALID BOOK NAME");
				}
				
				
			}
		 void display()
		 {
			 System.out.println("Name:"+title);
			 System.out.println("Author"+auhtor);
			 System.out.println("Price:"+price);
		}
	 
	public void price() {
		// TODO Auto-generated method stub
		
	}
	public void exit(int i) {
		// TODO Auto-generated method stub
		
	}
 }
public class library {
public static void main(String[] args)throws IOException
{
	Scanner in = new Scanner(System.in);  
    ArrayList<book>b1=new ArrayList<>();
      
    System.out.println("\n\n\t---LIBRARY--");  
    try  
    {  
         while(true)  
         {  
    System.out.println("\t1.Create book\n \t2.search book \n \t3.Exit.");  
         int ch = in.nextInt();  
         book b=new book();
         
              switch(ch)  
              {
                 
                   case 1: 
                	  
                   b.Createbook();
                   b1.add(b);
                   
                   break;  
                     
                   case 2: 
                	   for (book book : b1) {
						System.out.println("___________________");
						 book.display();
						 
					}
                   
                   break;  
                     
          
                   
                   case 3:
                	   System.exit(0);
                	   break;
                   default: System.out.println("Invalid Option");  
              }  
         }  
     }  
    catch(Exception e)  
    {  
         System.out.println("SELF THROWN EXCEPTION IS--->"+e);  
    }  
}
         }
